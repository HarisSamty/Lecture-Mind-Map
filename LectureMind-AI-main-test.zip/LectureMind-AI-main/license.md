# License for Mind Map LectureMind
<img src="https://raw.githubusercontent.com/linus-sch/Mind-Map-LectureMind/refs/heads/main/graphics/l-graphic.webp" alt="Mind Map LectureMind" style="width: 80%;">

This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.

**You are free to:**
- Share — copy and redistribute the material in any medium or format
- Adapt — remix, transform, and build upon the material

**Under the following terms:**
- Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
- NonCommercial — You may not use the material for commercial purposes.
<br>
For commercial use, please contact us at contact@mindmapLectureMind.com. We welcome opportunities for collaboration and partnership.
